import sqlite3
import subprocess
import pickle
import os

# 1. SQL injection (строка 9)
def get_user(username):
    conn = sqlite3.connect('db.sqlite')
    cursor = conn.cursor()
    query = "SELECT * FROM users WHERE name = '" + username + "'"
    cursor.execute(query)
    return cursor.fetchone()

# 2. Command injection (строка 16)
def ping_host(host):
    result = subprocess.call("ping -c 1 " + host, shell=True)
    return result

# 3. Хардкод пароля (строка 21)
SECRET_PASSWORD = "admin123"

# 4. Небезопасная десериализация pickle (строка 24)
def load_user_data(data):
    return pickle.loads(data)

# 5. Неиспользуемая опасная функция (строка 28)
def legacy_eval(expression):
    return eval(expression)

# 6. Потенциальный path traversal (строка 32)
def read_file(filename):
    with open("static/" + filename, "r") as f:
        return f.read()

# 7. Использование слабого хэша (строка 37)
import hashlib
def hash_password(password):
    return hashlib.md5(password.encode()).hexdigest()

# 8. Информация о среде (строка 42)
def get_debug_info():
    return os.environ.get("SECRET_KEY", "not_set")

if __name__ == "__main__":
    print(get_user("admin"))
    ping_host("google.com")
    print(hash_password("pass"))